"""Reproducible build identity; externally anchored by private vendor verification."""
PUBLIC_COMMIT = '8d5a24c06bf397f6ea7faaa7ec5a03e822909098'
PACKAGE_VERSION = '1.0.0'
RELEASE_MANIFEST_SHA256 = '93bb4bc185e82dd78eeb6e731dbde3714005032aa9015aab019dffd1bd17357f'
PROVENANCE_MANIFEST_SHA256 = '794657defbe6814622a214a1991a4fdace11b9ade1424436d3130d2352e80e72'
