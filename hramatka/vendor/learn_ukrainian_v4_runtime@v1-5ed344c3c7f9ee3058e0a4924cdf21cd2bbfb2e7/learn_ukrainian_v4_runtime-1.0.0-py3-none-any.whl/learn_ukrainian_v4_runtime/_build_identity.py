"""Reproducible build identity; externally anchored by private vendor verification."""
PUBLIC_COMMIT = '5ed344c3c7f9ee3058e0a4924cdf21cd2bbfb2e7'
PACKAGE_VERSION = '1.0.0'
RELEASE_MANIFEST_SHA256 = '1d948aeef161ce30c3893308c3fdff2109e2e1bd0672cef836be02aa4eafd35d'
PROVENANCE_MANIFEST_SHA256 = '6d00ce36953fead575306b9b5978d53ac16c2701970f6a5bc102e31d093b7061'
