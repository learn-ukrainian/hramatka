"""Reproducible build identity; externally anchored by private vendor verification."""
PUBLIC_COMMIT = '1e70c1280def6caa082d56623b32ca649025d3ad'
PACKAGE_VERSION = '1.0.0'
RELEASE_MANIFEST_SHA256 = 'fe284fdd771fada43fb6c968ce3a4020ec2cfb233691383454ef61e08aa577a7'
PROVENANCE_MANIFEST_SHA256 = 'c5f3b9c23d4cfea8bc921cdf932e3e8f0440a7d4fae5be6e37ec141d66902fa8'
