# License — Curriculum Content

**TL;DR**: The curriculum content (Ukrainian prose, dialogues, exercises, wiki articles, plans, translations, and explanations authored for this project) is licensed under **Creative Commons Attribution-ShareAlike 4.0 International (CC BY-SA 4.0)**. The software that builds it (Python scripts, TypeScript components, CI, tooling) is licensed separately under MIT — see `LICENSE` at the repository root.

---

## Project posture and good-faith use

This project is and will remain a **non-commercial, free, open-source educational resource** dedicated to helping learners of Ukrainian. The maintainer recorded this as a permanent project posture on 2026-04-19 — there is no commercial roadmap, no paid tier, no paywall, no advertising, and no plan to introduce any of the above. CC BY-NC dependencies (and other non-commercial-only sources) are acceptable inputs because the project itself is non-commercial.

Concretely, this means:

1. **Educational purpose only.** Every source we touch is touched for the purpose of teaching Ukrainian as a foreign language to English speakers (and adjacent learner groups), with decolonized pedagogy as a stated goal.
2. **No revenue, ever.** No ads, no sponsorships, no premium tier, no Patreon, no merch, no licensing-out. If the project ever needs hosting funds, those will be raised transparently and never tied to gating content.
3. **Good-faith application of fair use.** Where third-party material is used as RAG retrieval context for LLM generation (textbooks, dictionaries, style guides), the use is internal-context-only — never republished verbatim. Fair-use boundaries (≤200 chars per quotation, transformative use, attribution) are documented per source category below.
4. **Honest-mistake clause.** If a specific quotation, translation, or derivative work in this repository turns out to exceed the bounds we believed applied, that was an unintentional mistake — not an attempt to extract value from someone else's work. Open an issue or contact the maintainer and the offending content will be removed, paraphrased, or attributed within 7 days. The maintainer is reachable through the GitHub repository.
5. **Source-of-truth tracking.** Every dictionary, textbook, blog, video, and primary text we ingest is listed in this document with our understood license tier. If we add a new source, this file gets updated in the same PR. The historical record is preserved in git so the path of how each source landed in the project is auditable.
6. **License tiers, in plain language:**
   - **Public domain** (Shevchenko, Franko, Ukrainka, pre-1924 chronicles, Грінченко 1907, etc.) — quotable in full, attribution courtesy not requirement.
   - **Free with attribution** (Wikipedia CC BY-SA, Dobra Forma CC, VESUM open-source, free-to-view YouTube transcripts under fair-use educational frame) — usable, MUST cite.
   - **Fair use** (modern Ukrainian school textbooks, copyrighted dictionaries used as linguistic verification tooling) — internal RAG context only; ≤200-char direct quotations; transformative pedagogical use; never republished verbatim.
   - **All rights reserved** (commercial paid materials such as the Ukrainian Lessons Podcast paid membership, Anna Ohoiko premium PDFs, Анна-Ohoiko-authored books) — STUDY only by the maintainer for personal language reference, never copied into the repository, notes kept outside the repo (`~/.claude/projects/.../memory/` or gitignored `private-notes/`).

If you are a rights-holder of any source referenced in this document and believe our use exceeds the boundaries we describe, please open a GitHub issue or contact the maintainer directly. The intent is to teach Ukrainian; nothing in this project is intentionally adverse to source authors.

---

## What this file covers

This content license applies to everything in:

- `curriculum/**/*.md` — module prose
- `curriculum/**/activities/*.yaml` — activity definitions
- `curriculum/**/vocabulary/*.yaml` — per-module vocabulary
- `curriculum/**/plans/*.yaml` — module plans and outlines
- `curriculum/**/orchestration/**/*.md` — AI-generated orchestration notes
- `wiki/**/*.md` — compiled reference articles
- `starlight/src/content/docs/**/*.mdx` — rendered public site content
- `docs/l2-uk-en/*.md` — curriculum design docs (when they're teaching content, not tooling docs)

It does NOT cover:

- `scripts/**` — build tooling (MIT, see `LICENSE`)
- `starlight/src/components/**` — React component code (MIT, see `LICENSE`)
- `data/sources.db` and anything under `data/` — third-party source material under the licenses of the original authors (see "Third-party source material" below)
- `docs/references/private/` — copyrighted materials for the maintainer's personal verification only, NEVER redistributed
- `docs/resources/ukrainianlessons/**` — Ukrainian Lessons Podcast (ULP) commercial reference material, license-restricted, NEVER copy or redistribute

---

## The CC BY-SA 4.0 license in plain language

You are free to:

- **Share** — copy and redistribute the material in any medium or format
- **Adapt** — remix, transform, and build upon the material for any purpose, even commercially

Under the following terms:

- **Attribution** — You must give appropriate credit to the learn-ukrainian project (a link to https://learn-ukrainian.github.io is sufficient), provide a link to the license, and indicate if changes were made. You may do so in any reasonable manner, but not in any way that suggests the licensor endorses you or your use.
- **ShareAlike** — If you remix, transform, or build upon the material, you must distribute your contributions under the same license as the original.

No additional restrictions. You may not apply legal terms or technological measures that legally restrict others from doing anything the license permits.

The full legal text: https://creativecommons.org/licenses/by-sa/4.0/legalcode

---

## Why CC BY-SA 4.0

- **Share-alike is the whole point.** This curriculum exists to be copied, translated, adapted, and built upon. A share-alike clause keeps derivative works open — a fork that adds better explanations for German learners should be available to everyone, just like the original.
- **Commercial use is explicitly allowed.** A Ukrainian language school that prints a workbook from our modules is welcome, provided they attribute us and distribute the printed content under the same license. We want the materials in classrooms, not just online.
- **Attribution matters.** The project took hundreds of hours of native speaker review, LLM reasoning, and research. "Based on learn-ukrainian" is the minimum acknowledgment we ask for.
- **CC BY-SA 4.0 is widely understood.** It's the license Wikipedia uses. Most people know what it means without reading the legal text.

---

## Third-party source material

The curriculum is built with extensive reference to third-party sources. The handling of each is specified below.

### Ukrainian school textbooks (RAG corpus)

The project maintains a SQLite FTS5 index at `data/sources.db` containing ~23,000 chunks from Ukrainian school textbooks (grades 1-11) published by Заболотний, Авраменко, Вашуленко, Карман, Літвінова, Глазова, Bolshakova, and others. These are copyrighted works owned by their respective publishers.

**Fair use boundaries** (applied during wiki compilation and module authoring):

1. **Internal retrieval only.** Full textbook chunks are used as context for LLM generation and are never copied verbatim into module content. The wiki compilation prompts explicitly require the writer to synthesize information across sources and cite chunks by ID, not quote them at length.
2. **Maximum 200 characters per direct quotation.** Any direct quotation from a textbook that exceeds ~200 characters is a copyright compliance violation and must be paraphrased. Longer quotes are permitted only from public-domain works (chronicles, legal documents, etc. — see the "Primary sources" category below).
3. **Transformative use.** Our modules are pedagogically different from the source textbooks — same grammar topic, different presentation, different examples, different audience (English-speaking L2 learners). The transformation is substantive, not cosmetic.
4. **Educational non-profit use.** The curriculum is distributed free-of-charge with no ads, subscriptions, or paywalls.
5. **Attribution.** Every wiki article cites its sources with textbook author + grade + chunk ID. Every module's Ресурси tab lists the referenced textbooks.

The fair-use analysis above is based on U.S. Section 107 factors. If you intend to redistribute this work in a jurisdiction with different fair-use laws, consult your own counsel first.

### Primary historical and literary sources

Works published before 1924 (or otherwise in the public domain) are freely quotable in full. These include:

- The Primary Chronicle (Повість минулих літ), Галицько-Волинський літопис, Козацькі літописи
- Shevchenko, Franko, Ukrainka (full texts)
- Pre-1924 legal documents (Статути Великого князівства Литовського, etc.)
- Bylyny, dumas, folk songs collected by 19th-century ethnographers

These materials are stored in `data/sources.db` and referenced via the `literary` and `external` tables. Module content may quote them at any length, with attribution (author + work + year + chunk ID).

### Wikipedia

The curriculum uses Ukrainian and English Wikipedia articles as background context for seminar tracks (HIST, BIO, LIT, etc.). Wikipedia content is CC BY-SA 4.0 (same license as ours), so wiki-to-wiki attribution is straightforward: any derived content carries the Wikipedia attribution link in the wiki article's source list.

Wikipedia is NEVER cited as the primary source for historical dates, names, or events in published modules. The writer prompts (see `scripts/wiki/prompts/compile_article.md`) explicitly require primary-source citations and mark Wikipedia-only claims with `<!-- VERIFY -->`.

### External blogs, podcasts, and YouTube

- **ukrainianlessons.com** (Ukrainian Lessons Podcast, Anna Ohoiko) — **commercial, all rights reserved.** We may reference their free blog articles as external resources (link out only) but NEVER copy content from the paid ULP membership. The relationship is understood by the ULP author; see `docs/resources/external_resources.yaml` for the referenced URL set.
- **Реальна Історія (Akím Galímov), imtgsh, Istoria-Movy, Speak Ukrainian, Red Purple Ukrainian** — YouTube channels with free-to-view content. Subtitle transcripts are used internally for wiki compilation as context, not republished. Links to the original videos appear in module Ресурси tabs for learners.
- **Dobra Forma (opentext.ku.edu)** — Creative Commons licensed by the University of Kansas. We reference the URLs; derivative teaching material is separately attributed.
- **Горох (goroh.pp.ua), e2u (e2u.org.ua), Wikidata (wikidata.org), VESUM** — linguistic dictionaries and structured knowledge bases, freely available for educational use. Never redistributed in bulk; used only as query services.

### Dictionaries

The following dictionaries are ingested as SQLite FTS5 indices for internal linguistic verification only. They are NOT republished:

| Dictionary | License / Source | Use |
|---|---|---|
| **СУМ-11** | Public domain (Угода, Академія наук УРСР 1970-1980). ⚠️ Soviet-era ideologically framed for ~5.6% of entries (#1659 sovietization scan; risk-flagged at row level so reviewers can paraphrase or substitute). | Definitions (with sovietization-aware paraphrasing) |
| **Грінченко 1907** | Public domain (100+ years old). Tool prefix renamed to `search_grinchenko_1907` (#1679) for accuracy — this is a historical Ukrainian dictionary, not an etymology dictionary. | Pre-Soviet attestation, historical forms |
| **ЕСУМ vol 1 (А-Г)** | Academic dictionary, Інститут мовознавства НАН України. PoC scope = vol 1 only (PR #1672, 2026-05-04); vols 2-6 tracked in #1662. Used as RAG retrieval index for etymological context; not redistributed. | Etymology lookup |
| **slovnyk.me — SUM mirror** (`/dict/sum/`, `/dict/newsum/`, `/dict/linguistic_norm/`) | Per-query fair-use lookup against the public web mirror. Adopted 2026-05-05 as the modern definitional baseline replacement for the discontinued/incomplete СУМ-20 ingestion plan (#1667 superseded). Bulk redistribution NOT performed; queries cached locally for verifier reuse only. | Modern definitional baseline |
| **VESUM** | [MIT-ish, morphological database](https://github.com/brown-uk/dict_uk) | Lemma verification, POS tagging |
| **Балла EN→UK** | Historical work (copyright expired) | Translation assistance |
| **Антоненко-Давидович «Як ми говоримо»** | Copyrighted (Антоненко-Давидович estate). Used under fair-use for linguistic verification; individual style-rule citations in module content are limited to <200 chars. Currently 279 entries indexed of ~600+ in source; full-text ingestion of the 169-page text tracked in #1663 (open PDF at Internet Archive identifier `hovorymo1970` confirmed live 2026-05-05). | Calque / Russianism detection |
| **Гринчишин/Сербенська «Словник паронімів української мови» (1986 NBU scan)** | License says "use is for навчальною та науковою некомерційною метою" (educational and scientific non-commercial use). Aligns with project posture. Ingestion via NBU PDF OCR pending (#1666). | Paronym pair verification |
| **Karavansky «Російсько-український словник складної лексики» (r2u digital edition)** | r2u.org.ua/dicts/karavansky web edition; no API or bulk dump available. Per-query fair-use lookup planned (#1664); not yet ingested. | RU→UK complex lexicon |
| **Holovashchuk «Словник-довідник з українського літературного слововживання» (2004)** | ISBN 966-00-0350-1, Наукова думка. Original PDF link 404 as of 2026-05-05; ingestion path #1665 awaits an alternative source URL. License tier TBD when source is located. | Modern usage / norm |
| **Фразеологічний словник** | Copyrighted. Same fair-use boundaries as textbooks. | Idiom verification |
| **Правопис 2019** | Public (Академія наук України) | Orthography rules |
| **Ukrajinet WordNet** | 122K synsets; auto-translated from Open English WordNet per upstream README. ⚠️ Quality concern documented (#1657 Tier 3 audit). | Synonym lookup (with caveats) |
| **English Wiktionary via Kaikki.org / wiktextract** | English Wiktionary extract, **CC BY-SA 3.0**. Preprocessed from the local Kaikki Ukrainian JSONL extract into a compact per-lemma lookup; Atlas pages that use it render the attribution line "Pronunciation / etymology from English Wiktionary, CC BY-SA 3.0." | IPA pronunciation and final-fallback etymology |
| **e2u.org.ua** | Aggregator © r2u.org.ua (compilers Rysin, Starko et al.; constituent works: Гороть 2011/2016, Андрусишин–Крет 1955, scientific UK↔EN, …). Non-commercial educational use. | Per-query UK→EN lookup + short learner gloss + attribution. No bulk dump, no GitHub ingest. |
| **Wikidata** | CC0 (Wikimedia Foundation) | Per-query UK→EN lookup for Word Atlas translation fallback. No bulk dump, no GitHub ingest. |

---

## Contributions

Content contributed to this project (module text, exercise YAML, wiki article improvements, translations, corrections) is licensed under the same CC BY-SA 4.0 as the rest of the curriculum. By submitting a pull request, you agree that your contribution is CC BY-SA 4.0 licensed.

If you contribute code (not content), that's MIT — see `LICENSE`. The distinction matters: content goes out under CC BY-SA so forks stay open, code goes out under MIT so it can be freely integrated into other projects.

---

## Attribution boilerplate

When reusing material from this project, the following attribution line is sufficient:

> Based on the [learn-ukrainian curriculum](https://learn-ukrainian.github.io), licensed under [CC BY-SA 4.0](https://creativecommons.org/licenses/by-sa/4.0/).

For modified derivative works:

> Derived from the [learn-ukrainian curriculum](https://learn-ukrainian.github.io) (CC BY-SA 4.0). Modified by {your name / org}.

---

## Questions

Licensing questions go to issues on GitHub or the maintainer directly. The above is a best-effort plain-language summary of the legal position — it is not legal advice. If you need formal permissions or have commercial redistribution questions beyond the standard CC BY-SA 4.0 terms, open an issue and we'll figure it out.

Last updated: 2026-08-25 — added Wikidata (CC0, Wikimedia Foundation) for Word Atlas English translation lookup fallback (#4387). Predecessor: 2026-08-24 — added e2u.org.ua (Rysin, Starko et al.) for Word Atlas English translation lookup fallback (#4387). Predecessor: 2026-06-12 — added English Wiktionary via Kaikki.org / wiktextract (CC BY-SA 3.0) for Word Atlas IPA pronunciation and final-fallback etymology. Predecessor: 2026-05-05 — added good-faith / non-profit-posture section (user-requested defensive documentation), expanded dictionary inventory (ЕСУМ vol 1, slovnyk.me as СУМ-20 supersession, Гринчишин/Сербенська paronyms, Karavansky r2u, Holovashchuk pending, Ukrajinet caveat), noted СУМ-11 sovietization risk + Грінченко rename. Predecessor: 2026-04-11 (#1092).
